// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

import "forge-std/Test.sol";
import "../src/core/StakedBrokerRegistry.sol";
import "./mocks/MockUSDC.sol";

contract StakedBrokerTest is Test {
    StakedBrokerRegistry public registry;
    MockUSDC public usdc;

    address public owner = address(0x1);
    address public broker = address(0x10);
    address public victim = address(0x20);
    address public mockEscrow = address(0x30);

    uint256 public constant STAKE_AMOUNT = 2_000 * 1e6; // 2,000 USDC

    function setUp() public {
        vm.startPrank(owner);
        usdc = new MockUSDC();
        registry = new StakedBrokerRegistry(address(usdc));
        registry.setAuthorizedEscrow(mockEscrow, true);
        vm.stopPrank();

        usdc.mint(broker, 10_000 * 1e6);
        vm.prank(broker);
        usdc.approve(address(registry), type(uint256).max);
    }

    // =========================================================================
    // TEST 1: NẠP CỌC & CẤP TICK XANH (VERIFIED BADGE)
    // =========================================================================

    function test_StakeInsuranceGrantsVerification() public {
        vm.prank(broker);
        registry.stakeInsurance(STAKE_AMOUNT);

        IBrokerRegistry.BrokerProfile memory b = registry.getBroker(broker);
        assertEq(b.stakedBalance, STAKE_AMOUNT);
        assertTrue(b.isVerified);
        assertEq(registry.getAvailableQuota(broker), STAKE_AMOUNT);
    }

    // =========================================================================
    // TEST 2: CHỐNG SPOOFING (1 WEI KHÔNG ĐƯỢC CẤP TICK XANH)
    // =========================================================================

    function test_1WeiStakeDoesNotGrantTickXanh() public {
        address dustBroker = address(0x99);
        usdc.mint(dustBroker, 1);

        vm.startPrank(dustBroker);
        usdc.approve(address(registry), 1);
        registry.stakeInsurance(1); // Nạp 1 wei ($0.000001)
        vm.stopPrank();

        assertFalse(registry.isBrokerVerified(dustBroker));
    }

    // =========================================================================
    // TEST 3: RÚT CỌC CÓ UNBONDING COOLDOWN
    // =========================================================================

    function test_UnstakeRequiresUnbondingCooldown() public {
        vm.startPrank(broker);
        registry.stakeInsurance(STAKE_AMOUNT);

        // Yêu cầu rút 1,000 USDC
        registry.requestUnstake(1_000 * 1e6);

        // Chưa hết 24h cooldown -> Rút phải revert
        vm.expectRevert();
        registry.withdrawUnstaked();

        // Sau 24h
        vm.warp(block.timestamp + 1 days + 1);
        uint256 balanceBefore = usdc.balanceOf(broker);
        registry.withdrawUnstaked();
        assertEq(usdc.balanceOf(broker) - balanceBefore, 1_000 * 1e6);
        vm.stopPrank();
    }

    // =========================================================================
    // TEST 4: BẢO VỆ BẤT BIẾN KHI SLASHING (INVARIANT: STAKE >= ALLOCATED)
    // =========================================================================

    function test_SlashMaintainsInvariant() public {
        vm.prank(broker);
        registry.stakeInsurance(STAKE_AMOUNT);

        // Escrow cấp quota 1,000 USDC cho 1 kèo
        vm.prank(mockEscrow);
        assertTrue(registry.allocateQuota(broker, 1_000 * 1e6));
        assertEq(registry.getAvailableQuota(broker), 1_000 * 1e6);

        // Broker vi phạm, bị chém 1,500 USDC
        vm.prank(mockEscrow);
        registry.slashBroker(broker, victim, 1_500 * 1e6, 1_000 * 1e6);

        IBrokerRegistry.BrokerProfile memory b = registry.getBroker(broker);
        assertEq(b.stakedBalance, 500 * 1e6);
        // Quota phải được reset chuẩn xác để thỏa mãn bất biến stakedBalance >= activeHoldingAllocated
        assertGe(b.stakedBalance, b.activeHoldingAllocated);
        assertEq(b.slashedCount, 1);
        assertEq(usdc.balanceOf(victim), 1_500 * 1e6);
    }
}
