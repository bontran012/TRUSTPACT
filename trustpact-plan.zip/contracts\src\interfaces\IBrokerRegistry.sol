// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

/// @title IBrokerRegistry — Interface cho StakedBrokerRegistry
interface IBrokerRegistry {
    struct BrokerProfile {
        uint256 stakedBalance;
        uint256 activeHoldingAllocated;
        uint256 successfulDeals;
        uint256 slashedCount;
        bool isVerified;
        uint256 lastActiveTimestamp;
    }

    function allocateQuota(address broker, uint256 dealAmount) external returns (bool);
    function releaseQuota(address broker, uint256 dealAmount) external;
    function slashBroker(address broker, address victim, uint256 compensation, uint256 dealAmount) external;
    function getBroker(address broker) external view returns (BrokerProfile memory);
    function isBrokerVerified(address broker) external view returns (bool);
    function getAvailableQuota(address broker) external view returns (uint256);
}
