// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

import "@openzeppelin/contracts/token/ERC20/IERC20.sol";
import "../../src/interfaces/IUniversalEscrow.sol";

contract MockUniversalEscrow is IUniversalEscrow {
    IERC20 public immutable usdc;
    uint256 public escrowCounter;

    struct EscrowInfo {
        address buyer;
        address seller;
        address broker;
        uint256 amount;
        uint256 duration;
    }

    mapping(uint256 => EscrowInfo) public escrows;

    constructor(address _usdc) {
        usdc = IERC20(_usdc);
    }

    function createEscrow(
        address payable _seller,
        address _broker,
        uint256 _amount,
        uint256 _duration
    ) external override returns (uint256) {
        usdc.transferFrom(msg.sender, address(this), _amount);
        escrowCounter++;
        escrows[escrowCounter] = EscrowInfo({
            buyer: msg.sender,
            seller: _seller,
            broker: _broker,
            amount: _amount,
            duration: _duration
        });
        return escrowCounter;
    }

    function createEscrowFor(
        address payable _buyer,
        address payable _seller,
        address _broker,
        uint256 _amount,
        uint256 _duration
    ) external override returns (uint256) {
        usdc.transferFrom(msg.sender, address(this), _amount);
        escrowCounter++;
        escrows[escrowCounter] = EscrowInfo({
            buyer: _buyer,
            seller: _seller,
            broker: _broker,
            amount: _amount,
            duration: _duration
        });
        return escrowCounter;
    }
}
