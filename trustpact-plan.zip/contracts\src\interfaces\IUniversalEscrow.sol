// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

/// @title IUniversalEscrow — Interface cho Két Sắt Ký Quỹ 3 Bên UniversalEscrow
interface IUniversalEscrow {
    enum EscrowStatus { Active, Completed, Cancelled }

    struct EscrowItem {
        uint256 id;
        address buyer;
        address seller;
        address broker;
        address token; // address(0) for Native AVAX, otherwise ERC20 (e.g. USDC)
        uint256 amount;
        uint256 duration;
        uint256 startTime;
        EscrowStatus status;
        bool buyerCancelApproved;
        bool sellerCancelApproved;
    }

    function createEscrow(
        address seller,
        address broker,
        address token,
        uint256 amount,
        uint256 duration
    ) external payable returns (uint256);

    function createEscrowForBuyer(
        address buyer,
        address seller,
        address broker,
        address token,
        uint256 amount,
        uint256 duration
    ) external payable returns (uint256);

    function buyerConfirmDelivery(uint256 id) external;
    function brokerConfirmDelivery(uint256 id) external;
    function brokerRefundBuyer(uint256 id) external;
    function brokerMediateSettlement(uint256 id, uint256 refundToBuyer, uint256 payoutToSeller) external;
    function mutualCancelEscrow(uint256 id) external;
    function adminSlashCorruptBroker(uint256 id, uint256 compensation) external;
}
