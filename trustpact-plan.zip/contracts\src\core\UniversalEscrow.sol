// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

import "@openzeppelin/contracts/token/ERC20/IERC20.sol";
import "@openzeppelin/contracts/token/ERC20/utils/SafeERC20.sol";
import "@openzeppelin/contracts/utils/ReentrancyGuard.sol";
import "@openzeppelin/contracts/access/Ownable2Step.sol";
import "../interfaces/IUniversalEscrow.sol";
import "../interfaces/IBrokerRegistry.sol";

/// @title UniversalEscrow
/// @notice Két sắt ký quỹ bảo vệ 3 bên (Bên Mua - GDTG - Bên Bán)
/// @dev GDTG kiểm soát toàn bộ phòng giao dịch:
///      - Bàn giao xong: GDTG bấm giải ngân cho Bên Bán (hoặc Bên Mua tự bấm).
///      - Bên Bán ngâm kèo/không giao: GDTG bấm hoàn 100% tiền cọc cho Bên Mua ngay lập tức.
///      - Hai bên đàm phán phương án: GDTG bấm nút thực thi phân chia tiền đúng thỏa thuận 2 bên chốt.
///      - Nếu GDTG không làm được việc/gian dối: Người dùng TỐ CÁO LÊN SÀN -> Sàn chém cọc bảo hiểm GDTG đền bù cho nạn nhân!
/// @author TrustPact Protocol Team (Avalanche UniHack 2026)
contract UniversalEscrow is IUniversalEscrow, ReentrancyGuard, Ownable2Step {
    using SafeERC20 for IERC20;

    uint256 public constant PROTOCOL_FEE_BPS = 30;      // 0.30%
    uint256 public constant BROKER_FEE_BPS = 150;       // 1.50%
    uint256 public constant BPS_DENOMINATOR = 10000;

    address public treasury;
    address public brokerRegistry;
    address public authorizedAuctionBridge;

    mapping(uint256 => EscrowItem) public escrows;
    uint256 public counter;

    event EscrowCreated(
        uint256 indexed id,
        address indexed buyer,
        address indexed seller,
        address broker,
        address token,
        uint256 amount
    );
    event DeliveryConfirmed(uint256 indexed id, address indexed confirmedBy, uint256 sellerPayout, uint256 brokerFee);
    event RefundExecutedByBroker(uint256 indexed id, address indexed broker, uint256 refundAmount);
    event SettlementExecuted(uint256 indexed id, uint256 payoutToSeller, uint256 refundToBuyer);
    event EscrowCancelled(uint256 indexed id);
    event BrokerSlashedViaEscrow(uint256 indexed id, address indexed broker, uint256 compensation);

    error ZeroAddress();
    error ZeroAmount();
    error InvalidDuration();
    error InvalidStatus();
    error Unauthorized();
    error TransferFailed();
    error InsufficientValue();
    error EscrowAlreadyResolved();
    error SettlementAmountMismatch();

    modifier onlyTreasuryOrOwner() {
        if (msg.sender != treasury && msg.sender != owner()) revert Unauthorized();
        _;
    }

    constructor(
        address _treasury,
        address _brokerRegistry
    ) Ownable(msg.sender) {
        if (_treasury == address(0) || _brokerRegistry == address(0)) revert ZeroAddress();
        treasury = _treasury;
        brokerRegistry = _brokerRegistry;
    }

    function setTreasury(address _treasury) external onlyOwner {
        if (_treasury == address(0)) revert ZeroAddress();
        treasury = _treasury;
    }

    function setBrokerRegistry(address _brokerRegistry) external onlyOwner {
        if (_brokerRegistry == address(0)) revert ZeroAddress();
        brokerRegistry = _brokerRegistry;
    }

    function setAuthorizedAuctionBridge(address _bridge) external onlyOwner {
        if (_bridge == address(0)) revert ZeroAddress();
        authorizedAuctionBridge = _bridge;
    }

    /// @notice 1A. Bên Mua nạp tiền tạo phòng giao dịch ký quỹ 3 bên
    function createEscrow(
        address _seller,
        address _broker,
        address _token,
        uint256 _amount,
        uint256 _duration
    ) external payable override nonReentrant returns (uint256) {
        return _createEscrowInternal(msg.sender, _seller, _broker, _token, _amount, _duration, false);
    }

    /// @notice 1B. Cọc đấu giá chuyển thẳng sang tạo Escrow cho người thắng thầu
    function createEscrowForBuyer(
        address _buyer,
        address _seller,
        address _broker,
        address _token,
        uint256 _amount,
        uint256 _duration
    ) external payable override nonReentrant returns (uint256) {
        if (msg.sender != authorizedAuctionBridge && msg.sender != owner()) revert Unauthorized();
        return _createEscrowInternal(_buyer, _seller, _broker, _token, _amount, _duration, true);
    }

    function _createEscrowInternal(
        address _buyer,
        address _seller,
        address _broker,
        address _token,
        uint256 _amount,
        uint256 _duration,
        bool _isBridge
    ) internal returns (uint256 id) {
        if (_seller == address(0) || _buyer == address(0)) revert ZeroAddress();
        if (_amount == 0) revert ZeroAmount();
        if (_duration == 0) revert InvalidDuration();

        if (_broker != address(0)) {
            IBrokerRegistry(brokerRegistry).allocateQuota(_broker, _amount);
        }

        if (!_isBridge) {
            if (_token == address(0)) {
                if (msg.value < _amount) revert InsufficientValue();
            } else {
                IERC20(_token).safeTransferFrom(msg.sender, address(this), _amount);
            }
        }

        counter++;
        id = counter;

        escrows[id] = EscrowItem({
            id: id,
            buyer: _buyer,
            seller: _seller,
            broker: _broker,
            token: _token,
            amount: _amount,
            duration: _duration,
            startTime: block.timestamp,
            status: EscrowStatus.Active,
            buyerCancelApproved: false,
            sellerCancelApproved: false
        });

        emit EscrowCreated(id, _buyer, _seller, _broker, _token, _amount);
    }

    /// @notice 2A. Bên Mua tự bấm xác nhận đã nhận hàng
    function buyerConfirmDelivery(uint256 _id) external override nonReentrant {
        EscrowItem storage item = escrows[_id];
        if (msg.sender != item.buyer) revert Unauthorized();
        if (item.status != EscrowStatus.Active) revert InvalidStatus();

        _finalizeSuccessPayout(item, msg.sender);
    }

    /// @notice 2B. GDTG kiểm tra bàn giao xong -> bấm giải ngân cho Bên Bán
    function brokerConfirmDelivery(uint256 _id) external override nonReentrant {
        EscrowItem storage item = escrows[_id];
        if (msg.sender != item.broker) revert Unauthorized();
        if (item.status != EscrowStatus.Active) revert InvalidStatus();

        _finalizeSuccessPayout(item, msg.sender);
    }

    function _finalizeSuccessPayout(EscrowItem storage item, address confirmer) internal {
        item.status = EscrowStatus.Completed;

        uint256 platformFee = (item.amount * PROTOCOL_FEE_BPS) / BPS_DENOMINATOR;
        uint256 brokerFee = 0;

        if (item.broker != address(0)) {
            brokerFee = (item.amount * BROKER_FEE_BPS) / BPS_DENOMINATOR;
            IBrokerRegistry(brokerRegistry).releaseQuota(item.broker, item.amount);
        }

        uint256 netSellerPayout = item.amount - platformFee - brokerFee;

        if (platformFee > 0) _transferFunds(item.token, treasury, platformFee);
        if (brokerFee > 0) _transferFunds(item.token, item.broker, brokerFee);
        _transferFunds(item.token, item.seller, netSellerPayout);

        emit DeliveryConfirmed(item.id, confirmer, netSellerPayout, brokerFee);
        emit SettlementExecuted(item.id, netSellerPayout, 0);
    }

    /// @notice 3. GDTG kiểm soát: Bên Bán ngâm kèo / không giao / hủy kèo -> GDTG bấm HOÀN 100% TIỀN CHO BÊN MUA NGAY LẬP TỨC
    function brokerRefundBuyer(uint256 _id) external override nonReentrant {
        EscrowItem storage item = escrows[_id];
        if (msg.sender != item.broker) revert Unauthorized();
        if (item.status != EscrowStatus.Active) revert InvalidStatus();

        item.status = EscrowStatus.Completed;

        if (item.broker != address(0)) {
            IBrokerRegistry(brokerRegistry).releaseQuota(item.broker, item.amount);
        }

        _transferFunds(item.token, item.buyer, item.amount);
        emit RefundExecutedByBroker(_id, msg.sender, item.amount);
    }

    /// @notice 4. GDTG thực thi phương án đàm phán: Khi có trục trặc, hai bên tự thỏa thuận con số -> GDTG bấm nút chia tiền theo đúng cam kết
    function brokerMediateSettlement(
        uint256 _id,
        uint256 _refundToBuyer,
        uint256 _payoutToSeller
    ) external override nonReentrant {
        EscrowItem storage item = escrows[_id];
        if (msg.sender != item.broker) revert Unauthorized();
        if (item.status != EscrowStatus.Active) revert InvalidStatus();
        if (_refundToBuyer + _payoutToSeller != item.amount) revert SettlementAmountMismatch();

        item.status = EscrowStatus.Completed;

        if (item.broker != address(0)) {
            IBrokerRegistry(brokerRegistry).releaseQuota(item.broker, item.amount);
        }

        if (_refundToBuyer > 0) _transferFunds(item.token, item.buyer, _refundToBuyer);
        if (_payoutToSeller > 0) _transferFunds(item.token, item.seller, _payoutToSeller);

        emit SettlementExecuted(_id, _payoutToSeller, _refundToBuyer);
    }

    /// @notice 5. Hai bên Mua và Bán đồng thuận tự hủy kèo trong phòng giao dịch
    function mutualCancelEscrow(uint256 _id) external override nonReentrant {
        EscrowItem storage item = escrows[_id];
        if (item.status != EscrowStatus.Active) revert InvalidStatus();

        if (msg.sender == item.buyer) {
            item.buyerCancelApproved = true;
        } else if (msg.sender == item.seller) {
            item.sellerCancelApproved = true;
        } else {
            revert Unauthorized();
        }

        if (item.buyerCancelApproved && item.sellerCancelApproved) {
            item.status = EscrowStatus.Cancelled;

            if (item.broker != address(0)) {
                IBrokerRegistry(brokerRegistry).releaseQuota(item.broker, item.amount);
            }

            _transferFunds(item.token, item.buyer, item.amount);
            emit EscrowCancelled(_id);
        }
    }

    /// @notice 6. KHI GDTG KHÔNG LÀM ĐƯỢC VIỆC / GIAN DỐI / THÔNG ĐỒNG: Người dùng TỐ CÁO LÊN SÀN -> Sàn chém cọc GDTG đền bù nạn nhân
    function adminSlashCorruptBroker(uint256 _id, uint256 _compensation) external override onlyTreasuryOrOwner nonReentrant {
        EscrowItem storage item = escrows[_id];
        if (item.status != EscrowStatus.Active) revert EscrowAlreadyResolved();
        if (item.broker == address(0)) revert Unauthorized();

        item.status = EscrowStatus.Completed;

        // Hoàn trả 100% tiền cọc gốc cho Bên Mua
        _transferFunds(item.token, item.buyer, item.amount);

        // Chém cọc bảo hiểm của GDTG từ StakedBrokerRegistry đền bù thêm cho nạn nhân
        IBrokerRegistry(brokerRegistry).slashBroker(item.broker, item.buyer, _compensation, item.amount);

        emit BrokerSlashedViaEscrow(_id, item.broker, _compensation);
    }

    function _transferFunds(address _token, address _recipient, uint256 _amount) internal {
        if (_token == address(0)) {
            (bool success, ) = payable(_recipient).call{value: _amount}("");
            if (!success) revert TransferFailed();
        } else {
            IERC20(_token).safeTransfer(_recipient, _amount);
        }
    }

    function getEscrow(uint256 _id) external view returns (EscrowItem memory) {
        return escrows[_id];
    }
}
