// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

import "@openzeppelin/contracts/token/ERC20/ERC20.sol";

contract MockUSDC is ERC20 {
    constructor() ERC20("USD Coin", "USDC") {
        _mint(msg.sender, 1_000_000_000 * 1e6); // 1 Billion USDC
    }

    function decimals() public pure override returns (uint8) {
        return 6; // USDC standard 6 decimals
    }

    function mint(address to, uint256 amount) external {
        _mint(to, amount);
    }
}
