// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

import "forge-std/Test.sol";
import "../src/core/UniversalEscrow.sol";
import "../src/core/StakedBrokerRegistry.sol";
import "./mocks/MockUSDC.sol";

contract UniversalEscrowTest is Test {
    UniversalEscrow public escrow;
    StakedBrokerRegistry public registry;
    MockUSDC public usdc;

    address public owner = address(0x1);
    address public treasury = address(0x2);
    address public buyer = address(0x10);
    address public seller = address(0x20);
    address public broker = address(0x30);
    address public maliciousActor = address(0x99);

    uint256 public constant DEAL_AMOUNT = 1_000 * 1e6; // 1,000 USDC
    uint256 public constant BROKER_STAKE = 5_000 * 1e6; // 5,000 USDC
    uint256 public constant DURATION = 3 days;

    function setUp() public {
        vm.startPrank(owner);
        usdc = new MockUSDC();
        registry = new StakedBrokerRegistry(address(usdc));
        escrow = new UniversalEscrow(treasury, address(registry));

        // Authorize escrow on registry
        registry.setAuthorizedEscrow(address(escrow), true);
        vm.stopPrank();

        // Mint tokens
        usdc.mint(buyer, 10_000 * 1e6);
        usdc.mint(broker, 10_000 * 1e6);

        // Broker stakes 5,000 USDC to get verified and gain quota
        vm.startPrank(broker);
        usdc.approve(address(registry), BROKER_STAKE);
        registry.stakeInsurance(BROKER_STAKE);
        vm.stopPrank();

        assertTrue(registry.isBrokerVerified(broker));
        assertEq(registry.getAvailableQuota(broker), BROKER_STAKE);

        // Buyer approves escrow
        vm.prank(buyer);
        usdc.approve(address(escrow), type(uint256).max);
    }

    // =========================================================================
    // TEST 1: TẠO ESCROW & TỰ ĐỘNG KHÓA QUOTA BẢO LÃNH CỦA GDTG
    // =========================================================================

    function test_CreateEscrowAllocatesQuota() public {
        vm.prank(buyer);
        uint256 id = escrow.createEscrow(seller, broker, address(usdc), DEAL_AMOUNT, DURATION);

        assertEq(id, 1);
        // Quota của Broker bị trừ 1,000 USDC
        assertEq(registry.getAvailableQuota(broker), BROKER_STAKE - DEAL_AMOUNT);

        IUniversalEscrow.EscrowItem memory item = escrow.getEscrow(id);
        assertEq(item.buyer, buyer);
        assertEq(item.seller, seller);
        assertEq(item.broker, broker);
        assertEq(item.amount, DEAL_AMOUNT);
        assertEq(uint8(item.status), uint8(IUniversalEscrow.EscrowStatus.Active));
    }

    // =========================================================================
    // TEST 2: GDTG XÁC NHẬN BÀN GIAO THÀNH CÔNG -> GIẢI NGÂN CHO SELLER
    // =========================================================================

    function test_BrokerConfirmDeliveryReleasesFunds() public {
        vm.prank(buyer);
        uint256 id = escrow.createEscrow(seller, broker, address(usdc), DEAL_AMOUNT, DURATION);

        uint256 sellerBefore = usdc.balanceOf(seller);
        uint256 brokerBefore = usdc.balanceOf(broker);
        uint256 treasuryBefore = usdc.balanceOf(treasury);

        // GDTG kiểm tra bàn giao xong -> bấm giải ngân
        vm.prank(broker);
        escrow.brokerConfirmDelivery(id);

        // Platform fee: 0.3% = 3 USDC
        // Broker fee: 1.5% = 15 USDC
        // Net seller: 1,000 - 18 = 982 USDC
        assertEq(usdc.balanceOf(treasury) - treasuryBefore, 3 * 1e6);
        assertEq(usdc.balanceOf(broker) - brokerBefore, 15 * 1e6);
        assertEq(usdc.balanceOf(seller) - sellerBefore, 982 * 1e6);

        // Quota được giải phóng 100%
        assertEq(registry.getAvailableQuota(broker), BROKER_STAKE);
    }

    // =========================================================================
    // TEST 3: GDTG KIỂM SOÁT HOÀN TIỀN KHI SELLER NGÂM KÈO / KHÔNG GIAO
    // =========================================================================

    function test_BrokerRefundBuyerWhenSellerFails() public {
        vm.prank(buyer);
        uint256 id = escrow.createEscrow(seller, broker, address(usdc), DEAL_AMOUNT, DURATION);

        uint256 buyerBefore = usdc.balanceOf(buyer);

        // Seller không giao hàng, GDTG xác minh và bấm nút hoàn 100% tiền cho Buyer
        vm.prank(broker);
        escrow.brokerRefundBuyer(id);

        assertEq(usdc.balanceOf(buyer) - buyerBefore, DEAL_AMOUNT);
        assertEq(registry.getAvailableQuota(broker), BROKER_STAKE);
    }

    // =========================================================================
    // TEST 4: GDTG THỰC THI PHƯƠNG ÁN ĐÀM PHÁN PHÂN CHIA TIỀN CỦA 2 BÊN
    // =========================================================================

    function test_BrokerMediateSettlementExecutesAgreement() public {
        vm.prank(buyer);
        uint256 id = escrow.createEscrow(seller, broker, address(usdc), DEAL_AMOUNT, DURATION);

        uint256 buyerBefore = usdc.balanceOf(buyer);
        uint256 sellerBefore = usdc.balanceOf(seller);

        // Hai bên thỏa thuận: Hoàn 400 USDC cho Buyer, Trả 600 USDC cho Seller
        uint256 refundBuyer = 400 * 1e6;
        uint256 payoutSeller = 600 * 1e6;

        vm.prank(broker);
        escrow.brokerMediateSettlement(id, refundBuyer, payoutSeller);

        assertEq(usdc.balanceOf(buyer) - buyerBefore, refundBuyer);
        assertEq(usdc.balanceOf(seller) - sellerBefore, payoutSeller);
        assertEq(registry.getAvailableQuota(broker), BROKER_STAKE);
    }

    // =========================================================================
    // TEST 5: ĐỒNG THUẬN HỦY KÈO (MUTUAL CANCEL ESCROW)
    // =========================================================================

    function test_MutualCancelEscrowRefundsBuyer() public {
        vm.prank(buyer);
        uint256 id = escrow.createEscrow(seller, broker, address(usdc), DEAL_AMOUNT, DURATION);

        uint256 buyerBefore = usdc.balanceOf(buyer);

        // Buyer bấm đồng ý hủy
        vm.prank(buyer);
        escrow.mutualCancelEscrow(id);

        // Chưa hoàn nếu Seller chưa xác nhận
        assertEq(usdc.balanceOf(buyer), buyerBefore);

        // Seller bấm đồng ý hủy
        vm.prank(seller);
        escrow.mutualCancelEscrow(id);

        // 100% tiền hoàn về ví Buyer an toàn
        assertEq(usdc.balanceOf(buyer) - buyerBefore, DEAL_AMOUNT);
        // Quota được giải phóng
        assertEq(registry.getAvailableQuota(broker), BROKER_STAKE);
    }

    // =========================================================================
    // TEST 6: GDTG GIAN DỐI/KHÔNG LÀM ĐƯỢC VIỆC -> TỐ CÁO SÀN CHÉM CỌC GDTG
    // =========================================================================

    function test_AdminSlashCorruptBrokerCompensatesVictim() public {
        vm.prank(buyer);
        uint256 id = escrow.createEscrow(seller, broker, address(usdc), DEAL_AMOUNT, DURATION);

        uint256 buyerBefore = usdc.balanceOf(buyer);
        uint256 compensation = 500 * 1e6; // Chém thêm 500 USDC từ cọc của Broker đền bù cho Buyer

        // Admin sàn xử phạt GDTG vô trách nhiệm / thông đồng
        vm.prank(treasury);
        escrow.adminSlashCorruptBroker(id, compensation);

        // Buyer nhận: 1,000 USDC tiền cọc gốc + 500 USDC tiền phạt từ GDTG = 1,500 USDC
        assertEq(usdc.balanceOf(buyer) - buyerBefore, DEAL_AMOUNT + compensation);

        // Cố tình gọi lần 2 để hút tiền (Drain Attack) -> Phải REVERT!
        vm.prank(treasury);
        vm.expectRevert();
        escrow.adminSlashCorruptBroker(id, compensation);
    }
}
