// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

import "@openzeppelin/contracts/token/ERC20/IERC20.sol";
import "@openzeppelin/contracts/token/ERC20/utils/SafeERC20.sol";
import "@openzeppelin/contracts/utils/ReentrancyGuard.sol";
import "@openzeppelin/contracts/access/Ownable2Step.sol";
import "../interfaces/IBrokerRegistry.sol";

/// @title StakedBrokerRegistry
/// @notice Manages Staked Insurance Bonds, Dynamic Quota allocation, and Economic Slashing on Avalanche.
/// @author TrustPact Security Team (Avalanche UniHack 2026)
contract StakedBrokerRegistry is IBrokerRegistry, ReentrancyGuard, Ownable2Step {
    using SafeERC20 for IERC20;

    IERC20 public immutable usdc;
    uint256 public constant MINIMUM_STAKE_FOR_VERIFICATION = 50 * 1e6; // 50 USDC (6 decimals)
    uint256 public constant UNBONDING_DELAY = 1 days;

    mapping(address => BrokerProfile) public brokers;
    mapping(address => bool) public authorizedEscrows;
    mapping(address => uint256) public pendingUnstakeAmount;
    mapping(address => uint256) public unstakeAvailableAt;

    event BrokerStaked(address indexed broker, uint256 amount, uint256 totalStake);
    event BrokerUnstakeRequested(address indexed broker, uint256 amount, uint256 availableAt);
    event BrokerUnstaked(address indexed broker, uint256 amount);
    event StakeSlashed(address indexed broker, address indexed victim, uint256 compensation, uint256 dealAmount);
    event EscrowAuthorized(address indexed escrow, bool authorized);
    event BrokerBadgeRevoked(address indexed broker, string reason);

    error ZeroAddress();
    error ZeroAmount();
    error UnauthorizedEscrow();
    error InsufficientAvailableStake();
    error InsufficientStakeToSlash();
    error UnbondingPeriodNotMet();
    error NoPendingUnstake();
    error BrokerNotVerified();
    error ExceedsQuotaCapacity();

    modifier onlyAuthorizedEscrow() {
        if (!authorizedEscrows[msg.sender]) revert UnauthorizedEscrow();
        _;
    }

    constructor(address _usdc) Ownable(msg.sender) {
        if (_usdc == address(0)) revert ZeroAddress();
        usdc = IERC20(_usdc);
    }

    /// @notice Authorize or deauthorize an Escrow contract (UniversalEscrow)
    function setAuthorizedEscrow(address _escrow, bool _authorized) external onlyOwner {
        if (_escrow == address(0)) revert ZeroAddress();
        authorizedEscrows[_escrow] = _authorized;
        emit EscrowAuthorized(_escrow, _authorized);
    }

    /// @notice Broker deposits USDC insurance stake to obtain Verification Badge and deal quota
    function stakeInsurance(uint256 _amount) external nonReentrant {
        if (_amount == 0) revert ZeroAmount();

        BrokerProfile storage b = brokers[msg.sender];
        b.stakedBalance += _amount;
        if (b.stakedBalance >= MINIMUM_STAKE_FOR_VERIFICATION) {
            b.isVerified = true;
        }
        b.lastActiveTimestamp = block.timestamp;

        usdc.safeTransferFrom(msg.sender, address(this), _amount);

        emit BrokerStaked(msg.sender, _amount, b.stakedBalance);
    }

    /// @notice Request unstaking with a safety unbonding window
    function requestUnstake(uint256 _amount) external nonReentrant {
        if (_amount == 0) revert ZeroAmount();
        BrokerProfile storage b = brokers[msg.sender];

        // Ensure unstake does not touch collateral currently securing active deals
        if (b.stakedBalance < b.activeHoldingAllocated + _amount) {
            revert InsufficientAvailableStake();
        }

        b.stakedBalance -= _amount;
        if (b.stakedBalance < MINIMUM_STAKE_FOR_VERIFICATION) {
            b.isVerified = false;
            emit BrokerBadgeRevoked(msg.sender, "Stake below minimum threshold");
        }

        pendingUnstakeAmount[msg.sender] += _amount;
        unstakeAvailableAt[msg.sender] = block.timestamp + UNBONDING_DELAY;

        emit BrokerUnstakeRequested(msg.sender, _amount, unstakeAvailableAt[msg.sender]);
    }

    /// @notice Complete withdrawal of unbonded stake once cooldown has elapsed
    function withdrawUnstaked() external nonReentrant {
        uint256 amount = pendingUnstakeAmount[msg.sender];
        if (amount == 0) revert NoPendingUnstake();
        if (block.timestamp < unstakeAvailableAt[msg.sender]) revert UnbondingPeriodNotMet();

        pendingUnstakeAmount[msg.sender] = 0;
        unstakeAvailableAt[msg.sender] = 0;

        usdc.safeTransfer(msg.sender, amount);
        emit BrokerUnstaked(msg.sender, amount);
    }

    /// @notice Allocates quota to back an active deal, strictly verifying stake collateral
    function allocateQuota(address _broker, uint256 _dealAmount) external override onlyAuthorizedEscrow returns (bool) {
        BrokerProfile storage b = brokers[_broker];
        if (!b.isVerified) return false;

        // Invariant check: cannot allocate more than free staked capital
        if (b.stakedBalance < b.activeHoldingAllocated + _dealAmount) {
            return false;
        }

        b.activeHoldingAllocated += _dealAmount;
        b.lastActiveTimestamp = block.timestamp;
        return true;
    }

    /// @notice Releases allocated quota upon deal resolution and increases successful deal count
    function releaseQuota(address _broker, uint256 _dealAmount) external override onlyAuthorizedEscrow {
        BrokerProfile storage b = brokers[_broker];
        if (b.activeHoldingAllocated >= _dealAmount) {
            b.activeHoldingAllocated -= _dealAmount;
        } else {
            b.activeHoldingAllocated = 0;
        }
        b.successfulDeals++;
        b.lastActiveTimestamp = block.timestamp;
    }

    /// @notice Slashes corrupt broker's collateral, releases active deal quota, and compensates the victim
    function slashBroker(
        address _broker,
        address _victim,
        uint256 _compensation,
        uint256 _dealAmount
    ) external override onlyAuthorizedEscrow nonReentrant {
        if (_victim == address(0)) revert ZeroAddress();
        BrokerProfile storage b = brokers[_broker];
        if (b.stakedBalance < _compensation) revert InsufficientStakeToSlash();

        // Deduct slash penalty from total stake
        b.stakedBalance -= _compensation;

        // Release the deal quota associated with this dispute
        if (b.activeHoldingAllocated >= _dealAmount) {
            b.activeHoldingAllocated -= _dealAmount;
        } else {
            b.activeHoldingAllocated = 0;
        }

        // Guarantee protocol invariant: stakedBalance >= activeHoldingAllocated
        if (b.activeHoldingAllocated > b.stakedBalance) {
            b.activeHoldingAllocated = b.stakedBalance;
        }

        if (b.stakedBalance < MINIMUM_STAKE_FOR_VERIFICATION) {
            b.isVerified = false;
            emit BrokerBadgeRevoked(_broker, "Slashed below minimum stake");
        }

        b.slashedCount++;
        b.lastActiveTimestamp = block.timestamp;

        usdc.safeTransfer(_victim, _compensation);
        emit StakeSlashed(_broker, _victim, _compensation, _dealAmount);
    }

    /// @notice Returns full broker profile
    function getBroker(address _broker) external view override returns (BrokerProfile memory) {
        return brokers[_broker];
    }

    /// @notice Checks if broker holds verified status
    function isBrokerVerified(address _broker) external view override returns (bool) {
        return brokers[_broker].isVerified;
    }

    /// @notice Returns remaining unallocated quota available for new deals
    function getAvailableQuota(address _broker) external view override returns (uint256) {
        BrokerProfile storage b = brokers[_broker];
        if (!b.isVerified || b.stakedBalance <= b.activeHoldingAllocated) {
            return 0;
        }
        return b.stakedBalance - b.activeHoldingAllocated;
    }
}
